import math
#y = (m * x) + (m2 * math.pow(x,2)) + (m3 * math.pow(x,3)) + (m4 * math.cos(x)) + (m5 * math.sin(x)) + (m6 * math.factorial(int(x)) + b

#Declare variables-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Data_x = []
Data_y = []
epochs = 0
learning_rate = 0

x = 0
m = 0
m2 = 0
m3 = 0
m4 = 0
m5 = 0
b = 0
y = 0

best_b_save = 0
best_m_save = 0
best_m2_save = 0
best_m3_save = 0
best_m4_save = 0
best_m5_save = 0
best_m6_save = 0
best_tolerance_save = 0

b_max = 0
m_max = 0
m2_max = 0
m3_max = 0
m4_max = 0
m5_max = 0
m6_max = 0

b = 0
m = 0
m2 = 0
m3 = 0
m4 = 0
m5 = 0
m6 = 0

ra = 0

#END declare variables-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#INSIDE DATA USE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def plus_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] - Data_x[i]
  ra = ra / len(Data_x)
  return(ra)

def multiply_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / Data_x[i]
  ra = ra / len(Data_x)
  return(ra)

def pow2_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / math.pow(Data_x[i],2)
  ra = ra / len(Data_x)
  return(ra)

def pow3_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / math.pow(Data_x[i],3)
  ra = ra / len(Data_x)
  return(ra)

def cos_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / math.cos(Data_x[i])
  ra = ra / len(Data_x)
  return(ra)

def sin_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / math.sin(Data_x[i])
  ra = ra / len(Data_x)
  return(ra)

def factoria_test():
  global Data_x,Data_y,ra
  ra = 0
  for i in range (len(Data_x)):
    ra += Data_y[i] / math.factorial(Data_x[i])
  ra = ra / len(Data_x)
  return(ra)

def convergence_ver_setting():
  global m,b,b_max,m_max,m2,m3,m4,m5,m2_max,m3_max,m4_max,m5_max,m6,m6_max
  if m > m_max:
    b += learning_rate
    m = 0 - m_max
  if b > b_max:
    m2 += 1
    b = 0 - b_max
  if m2 > m2_max:
    m3 += learning_rate
    m2 = 0 - m2_max
  if m3 > m3_max:
    m4 += learning_rate
    m3 = 0 - m3_max
  if m4 > m4_max:
    m5 += learning_rate
    m4 = 0 - m4_max
  if m5 > m5_max:
    m6 += learning_rate
    m5 = 0 - m5_max
  if m6 > m6_max:
    b_max = b_max * 2
    m_max = m_max * 2
    m2_max = m2_max * 2
    m3_max = m3_max * 2
    m4_max = m4_max * 2
    m5_max = m5_max * 2
    m6_max = m6_max * 2
    b = 0 - b_max
    m = 0 - m_max
    m2 = 0 - m2_max
    m3 = 0 - m3_max
    m4 = 0 - m4_max
    m5 = 0 - m5_max
    m6 = 0 - m6_max

def best_save():
  global Data_x,Data_y,m,b,best_b_save,best_m_save,best_tolerance_save,best_m2_save,best_m3_save,best_m4_save,best_m5_save,m2,m3,m4,m5,m6,best_m6_save
  if tolerance_save() < best_tolerance_save:
    best_b_save = b
    best_m_save = m
    best_m2_save = m2
    best_m3_save = m3
    best_m4_save = m4
    best_m5_save = m5
    best_m6_save = m6
    best_tolerance_save = tolerance_save()

def save():
  global Data_x,Data_y,m,b,best_b_save,best_m_save,best_tolerance_save,best_m2_save,best_m3_save,best_m4_save,best_m5_save,m2,m3,m4,m5,m6,best_m6_save
  best_b_save = b
  best_m_save = m
  best_m2_save = m2
  best_m3_save = m3
  best_m4_save = m4
  best_m5_save = m5
  best_m6_save = m6
  best_tolerance_save = tolerance_save()

def tolerance_save():
  global Data_x,Data_y,ra,m,m2,m3,m4,m5,m6
  ra = 0
  for i in range(len(Data_x)):
    if (Data_y[i] - ((m * Data_x[i]) + (m2 * math.pow(Data_x[i],2)) + (m3 * math.pow(Data_x[i],3)) + (m4 * math.cos(Data_x[i])) + (m5 * math.sin(Data_x[i])) + (m6 * math.factorial(int(Data_x[i]))) + b)) > 0:
      ra += (Data_y[i] - ((m * Data_x[i]) + ((m2 * math.pow(Data_x[i],2)) + (m3 * math.pow(Data_x[i],3)) + (m4 * math.cos(Data_x[i])) + (m5 * math.sin(Data_x[i])) + (m6 * math.factorial(int(Data_x[i])))) + b))
    else:
      ra += 0 - (Data_y[i] - ((m * Data_x[i]) + (m2 * math.pow(Data_x[i],2)) + (m3 * math.pow(Data_x[i],3)) + (m4 * math.cos(Data_x[i])) + (m5 * math.sin(Data_x[i])) + (m6 * math.factorial(int(Data_x[i]))) + b))
   
  ra = ra / len(Data_x)
  return(ra)

#END INSIDE DATA USE---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#Function User Use-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def equation_formula_use():
  return("y = (m * x) + (m2 * math.pow(x,2)) + (m3 * math.pow(x,3)) + (m4 * math.cos(x)) + (m5 * math.sin(x)) + (m6 * math.factorial(int(x)) + b")

def build_model(DataX,DataY,Epochs,LearningRate):
  global Data_x,Data_y,epochs,learning_rate,b_max,m_max,m2_max,m2_max,m4_max,m5_max,m6_max,b,m,m2,m3,m4,m5,m6
  Data_x = DataX
  Data_y = DataY
  epochs = Epochs
  learning_rate = LearningRate
  b_max = int(plus_test())
  m_max = int(multiply_test())
  m2_max = int(pow2_test())
  m3_max = int(pow3_test())
  m4_max = int(cos_test())
  m5_max = int(sin_test())
  m6_max = int(factoria_test())

  b = 0 - b_max
  m = 0 - m_max
  m2 = 0 - m2_max
  m3 = 0 - m3_max
  m4 = 0 - m4_max
  m5 = 0 - m5_max
  m6 = 0 - m6_max
  save()

def inputX(X):
  global x
  x = X

def reset_training():
  global m,m2,m3,m4,m5,m6,b,y,best_b_save,best_m_save,best_m2_save,best_m3_save,best_m4_save,best_m5_save,best_m6_save,best_tolerance_save,ra
  m = 0
  m2 = 0
  m3 = 0
  m4 = 0
  m5 = 0
  b = 0
  y = 0

  best_b_save = 0
  best_m_save = 0
  best_m2_save = 0
  best_m3_save = 0
  best_m4_save = 0
  best_m5_save = 0
  best_m6_save = 0
  best_tolerance_save = 0

  ra = 0

def training_model():
  global i,m,learning_rate,epochs
  i = 0
  while i < epochs + 1:
    m += learning_rate
    i += 1
    convergence_ver_setting()
    best_save()

def return_data():
  global best_b_save,best_m_save,best_m2_save,best_m3_save,best_m4_save,best_m5_save,best_m6_save,best_tolerance_save
  return([best_b_save,best_m_save,best_m2_save,best_m3_save,best_m4_save,best_m5_save,best_m6_save,best_tolerance_save])

def returnY():
  return(((best_m_save * x) + (best_m2_save * math.pow(x,2)) + (best_m3_save * math.pow(x,3)) + (best_m4_save * math.cos(x)) + (best_m5_save * math.sin(x)) + (best_m6_save * math.factorial(int(x))) + best_b_save))

def how_to_use():
  print("""This library has a total of 10 function.
-----------------------------------------------------
1. equation_formula_use()

Used for specifying the equation used. The output data will be of a string type

Example of usage: 
print(equation_formula_use())
-----------------------------------------------------
2.build_model(DataX,DataY,Epochs,LearningRate)

Used for creating models and requires the following information.

DataX is list for collect question.
DataY is list for collect answer.
Epochs is number of training model.
LearningRate is adjusting values for finding parameters.

Example of usage:
build_model([1,2,3,4,5],[2,4,6,8,10],10000,1)
-----------------------------------------------------
3.reset_training()

Used for restoring training data.

Example of usage:
reset_traning()
-----------------------------------------------------
4.inputX(X)

Used for entering the information you want to find. 

X is the information you want to find.

Example of usage:
inputX(100)
-----------------------------------------------------
5.training_model()

Used for training the model. The training time will be as much as the specified amount.

Example of usage:
training_model()
-----------------------------------------------------
6.return_data()

Used for return the parameters found and the expected deviations of the found answers.

The values will be returned in the form of a list.

Example of usage:
print(retrun_data())
-----------------------------------------------------
7.returnY()

Use to return the found answer.

Example of usage:
print(retrunY())
-----------------------------------------------------
8.how_to_use()

Used for telling how to use.

Example of usage:
how_to_use()
-----------------------------------------------------
9.pf_set(b,m,m2,m3,m4,m5,m6,b_max,m_max,m2_max,m3_max,m4_max,m5_max,m6_max)

Used for setting parameters and parameter search scope.

Example of usage:
pf_set(-100,-25,-25,-25,-25,-25,100,25,25,25,25,25)
-----------------------------------------------------
10.fz_out()

Used for specifying the scope of the search.

Example of usage:
print(fz_out())
-----------------------------------------------------""")

def pf_set(b_in,m_in,m2_in,m3_in,m4_in,m5_in,m6_in,b_max_in,m_max_in,m2_max_in,m3_max_in,m4_max_in,m5_max_in,m6_max_in):
  global b,m,m2,m3,m4,m5,m6,b_max,m_max,m2_max,m3_max,m4_max,m5_max,m6_max
  b = b_in
  m = m_in
  m2 = m2_in
  m3 = m3_in
  m4 = m4_in
  m5 = m5_in
  m6 = m6_in
  b_max = b_max_in
  m_max = m_max_in
  m2_max = m2_max_in
  m3_max = m3_max_in
  m4_max = m4_max_in
  m5_max = m5_max_in
  m6_max = m6_max_in

def fz_out():
  global b_max,m_max,m2_max,m3_max,m4_max,m5_max,m6_max
  return([b_max,m_max,m2_max,m3_max,m4_max,m5_max,m6_max])

#END Function User Use-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------